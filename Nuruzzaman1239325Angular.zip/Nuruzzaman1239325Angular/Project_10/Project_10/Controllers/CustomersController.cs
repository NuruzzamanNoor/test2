﻿using Project_10.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace Project_10.Controllers
{
    public class CustomersController : ApiController
    {
        ExamModel db = new ExamModel();

        public IHttpActionResult PostCustomer(CustomerVm customervm)
        {
            var customer = new Customer
            {
                Name = customervm.Name,
                Picture = customervm.Picture,
            };
            db.Customers.Add(customer);
            db.SaveChanges();

            return Ok();

        }
        public IHttpActionResult PutCustomer(CustomerVm customervm)
        {
            var customer = new Customer
            {
                Name = customervm.Name,
                Picture = customervm.Picture,
                Id=customervm.Id
            };
            db.Entry(customer).State = System.Data.Entity.EntityState.Modified;

            db.SaveChanges();

            return Ok();

        }
        public IQueryable<Customer>  GetCustomers()
        {
            return db.Customers;
        }
        public Customer GetCustomers(int id)
        {
            return db.Customers.Find(id);
        }
        public int DeleteCustomer(int id)
        {
            db.Customers.Remove(db.Customers.Find(id));
           return db.SaveChanges()   ;
        }
    }
}
