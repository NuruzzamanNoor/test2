﻿using Project_10.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;

namespace Project_10.Controllers
{
    public class CustomerMvcController : Controller
    {
        // GET: CustomerMvc
        public ActionResult Index()
        {
            IList<Customer> customerlist=null     ;
            using (var client = new HttpClient())
            {

                //client.BaseAddress =new Uri("http://localhost:8445/api/Customers");
                var result = client.GetAsync("http://localhost:8445/api/Customers");
                   result.Wait();
                if(result.IsCompleted)
                {
                    var response = result.Result.Content.ReadAsAsync< IList < Customer >>();
                    response.Wait();
                    customerlist = response.Result;
                }
            }

                return View(customerlist);
        }
        [HttpGet]
        public ActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Create(HttpPostedFileBase imgfile, CustomerVm cstvm)
        {
            var client = new HttpClient();
            if(ModelState.IsValid)
            {
                if(imgfile.ContentLength>0 || imgfile !=null)
                {
                    string ext =Path.GetExtension(imgfile.FileName);
                    cstvm.Picture = new byte[imgfile.ContentLength];
                    imgfile.InputStream.Read(cstvm.Picture, 0, imgfile.ContentLength);
                    var result = client.PostAsJsonAsync("http://localhost:8445/api/Customers", cstvm).Result;
                    if(result.StatusCode == System.Net.HttpStatusCode.OK)
                    {
                      return  RedirectToAction("Index");
                    }
                }

            }

            return View();
        }
        [HttpGet]
        public ActionResult Edit(int id)
        {
            using(var client= new HttpClient())
            {
               CustomerVm customer = null;
                var result = client.GetAsync("http://localhost:8445/api/Customers/" + id);
                result.Wait();
                if (result.Result.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    customer = result.Result.Content.ReadAsAsync<CustomerVm>().Result;

                    return View(customer);
                }
            }
            return View();
        }
        [HttpPost]
        public ActionResult Edit(HttpPostedFileBase imgfile, CustomerVm cstvm)
        {
            var client = new HttpClient();
            if (ModelState.IsValid)
            {
                if (imgfile.ContentLength > 0 || imgfile != null)
                {
                    string ext = Path.GetExtension(imgfile.FileName);
                    cstvm.Picture = new byte[imgfile.ContentLength];
                    imgfile.InputStream.Read(cstvm.Picture, 0, imgfile.ContentLength);
                   
                }
                var result = client.PutAsJsonAsync("http://localhost:8445/api/Customers", cstvm).Result;
                if (result.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    return RedirectToAction("Index");
                }


            }

            return View();
        }
        public ActionResult Delete(int id)
        {
            var client = new HttpClient();
            
            var result = client.DeleteAsync("http://localhost:8445/api/Customers/" + id.ToString());
            result.Wait();
            if (result.Result.IsSuccessStatusCode)
            {
                return RedirectToAction("Index");
            }
            ModelState.AddModelError("", "Error occured to save");
            return View();
        }
    }
}