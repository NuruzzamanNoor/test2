﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;
using System.Linq;
using System.Threading.Tasks;

namespace Project_10.Models
{
    public class ExamModel:DbContext
    {
       

        public DbSet<Customer> Customers { get; set; }

        public System.Data.Entity.DbSet<Project_10.Models.CustomerVm> CustomerVms { get; set; }
    }

    public class Customer
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public Byte[] Picture { get; set; }
       
    }
}
